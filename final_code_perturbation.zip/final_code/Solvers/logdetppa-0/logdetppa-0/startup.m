%%*************************************************************************
%%
%%
%%*************************************************************************

%%
  path(strcat(pwd,'/solver'),path); 
  path(strcat(pwd,'/solver/mexfun'),path); 
  path(strcat(pwd,'/util'),path); 
  path(strcat(pwd,'/runexpt'),path); 
%%
%%
  set(0,'defaultaxesfontsize',14);
  set(0,'defaultlinemarkersize',6);
  set(0,'defaulttextfontsize',14);
%%*************************************************************************
