clear all 
close all

addpath('/Users/armeentaeb/Dropbox/Research_at_ETH/Code')
addpath('/Users/armeentaeb/Dropbox/Research_at_ETH/Code/Solvers')
addpath('/Users/armeentaeb/Dropbox/R_code_paper/files')
addpath('/Users/armeentaeb/Dropbox/Research_at_ETH/Code/DirectLikelihood');
addpath('/Users/armeentaeb/Dropbox/Research_at_ETH/Code/DirectLikelihood');
addpath('/Users/armeentaeb/Dropbox/Research_at_ETH/Code/DirectLikelihood/cvx');
cvx_startup
cvx_setup
global equivar
equivar = 1;
global Sigma; % consists of covariances across environments
global env_num;
Sigma = cell(7,1);
global learn_rate 
global nvec
learn_rate = 0.01;
global Bstar;
global latent; latent = 1;
global rank_est;rank_est = 3;
global perturbed_latent; perturbed_latent = 1;
global psi_max; psi_max = 0.5;
global R;
global ratio_BIC; ratio_BIC = 1;

addpath('/Users/armeentaeb/Dropbox/R_code_paper/files_4/');
link = '/Users/armeentaeb/Dropbox/R_code_paper/files_4/mismatch_nonlinear_13/';
Bstar = load('population_Bstar');

num_obs = 300;
p = 10;
nvec = [300 5 5 5 5 5 5];
R = ones(p,length(nvec));


equivalent_DAGs = cell(9*2,1);
for i = 1:9
    equivalent_DAGs{2*i-1} = load(strcat('equivalent_DAGS_',string(i)));
    B = equivalent_DAGs{2*i-1};
    ind = find(B == 1);
    isDAG = 0;
    while ~isDAG
        Bnew = B;
        t = randperm(length(ind));
        Bnew(ind(t(1:2))) = 0;
        sumv = 0;
        for j = 1:p
            sumv = sumv + trace(Bnew^j);
        end
        isDAG = (sumv == 0);
    end
    equivalent_DAGs{2*i} = Bnew;
end

iterv = [64,16,4];
FP_final = zeros(p^2,length(iterv)); TP_final = zeros(p^2,length(iterv)); 
for j =1:length(iterv)
    link_in = strcat(link,string(iterv(j)*5),'_samples/');
    nvec = [num_obs 5*iterv(j)*ones(1,6)];

    FP_tot = zeros(p^2,1);
    TP_tot = zeros(p^2,1);
    FP_tot_singleparam = zeros(p^2,1);
    TP_tot_singleparam = zeros(p^2,1);

    for iter = 1:10
         link_final = strcat(link_in,'equivalent_DAGS_GES',string(iter));
        tot_data = load(link_final);
       % equivalent_DAGs = cell(size(tot_data,1)/p,1);
       % for l = 1:size(tot_data,1)/p
       %     equivalent_DAGs{l} = tot_data(1+(l-1)*p:p*l,:);
       % end
        nvec = [num_obs 5*iterv(j)*ones(1,6)];

        link_final = strcat(link_in,'overall_data',string(iter));
        tot_data = load(link_final);
        data_obs = tot_data(1:num_obs,:);
        bad_env = zeros(length(nvec),1);
        Sigma{1} = cov(data_obs);
        
        for iter_2 = 1:6
            Sigma{iter_2+1} = cov(tot_data(num_obs+5*iterv(j)*(iter_2-1)+1:num_obs+5*iterv(j)*(iter_2-1)+5*iterv(j),:));
            if cond(Sigma{iter_2+1}) >= 10^(4)
                bad_env(iter_2+1) = 1;
            end
        end
        
        ind_bad = find(bad_env == 1);
        Sigma(ind_bad) = [];
        nvec(ind_bad) = [];
        
        
        [optimal_Bv1, Gamma,d0, scorev1] = score_all_dags_set(equivalent_DAGs);
        [val,ind] = min(scorev1);
        
         [val1,ind1] = min(scorev1);
         optimal_B_est_orig = optimal_Bv1{ind1};
    
%     
%     score = scorev1(ind1);
%     l = 1;
%     equivalent_DAGs_new = equivalent_DAGs{ind1};
%     optimal_B_est_new = optimal_B_est_orig;
%     while l<= length(find(abs(optimal_B_est_orig)>10^(-3)))
%         optimal_B_est = optimal_B_est_new;
%         scoren = score;
%         equivalent_DAGs_est = equivalent_DAGs_new;
%         ind = (find(abs(optimal_B_est)>10^(-3)));
%         [val ind2] = sort(abs(optimal_B_est(ind)),'ascend');
%         equivalent_DAGs_new(ind(ind2(1))) = 0;
%         equivalent_DAGs2 = cell(1);
%         equivalent_DAGs2{1} = equivalent_DAGs_new;
%         [optimal_B_est_new,~,~,scoren] = score_all_dags_set(equivalent_DAGs2);
%         optimal_B_est_new = optimal_B_est_new{1};
%         if scoren > score
%             break;
%         end
%         l = l+1;
%     end
%         
%     B_opt = optimal_B_est;    
        clear equivalent_DAGs2;
        equivalent_DAGs2 = [];
        l = 1;
            if sum(sum((abs(optimal_Bv1{ind1})<=0.5*10^(-1)).*(abs(optimal_Bv1{ind1})>0)))~=0
               equivalent_DAGs2{l} = abs(optimal_Bv1{ind1})>0.5*10^(-1); 
            end
          
        if size(equivalent_DAGs2)>=1
            [optimal_Bv2,Gamma,d0,scorev2] = score_all_dags_set(equivalent_DAGs2');
        else
            scorev2 = 1000000;
        end
        
        [val1,ind1] = min(scorev1);[val2,ind2] = min(scorev2); [~,ind3] = min([val1,val2]);
        if val1< val2
            B_opt = optimal_Bv1{ind1};
        else
             B_opt = optimal_Bv2{ind2};

        end
        
        [FP,TP] = evaluate_error_connectivity(B_opt);
        FP_tot = FP_tot+FP; TP_tot = TP_tot+TP;
               
    end    
    FP_tot = FP_tot/10;
    TP_tot = TP_tot/10;
    FP_final(:,j) = FP_tot; TP_final(:,j) = TP_tot;  
end
