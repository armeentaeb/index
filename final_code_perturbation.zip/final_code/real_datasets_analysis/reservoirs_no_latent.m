%% This is a demo for the paper "A Statistical Graphical Model of the California Reservoir Network
%% Written by Armeen Taeb, California Institute of Technology, December 2016
close all
clear all
clc

%%  Define globa variables for solvers
global GM; % Graphical modeling
global LVGM; % Latent variable graphical modeling
global Conditional_LVGM; % Conditional latent variable graphical modeling
GM = 1;
LVGM = 2;
Conditional_LVGM = 3;
global covariatesName; % cell containing name of the covariates
global resInfo
global TrainTest
global root
global Sigma
global nvec
global learn_rate
global perturbed_latent
global latent
global psi_max
global rank_est
global R
addpath('/Users/armeentaeb/Dropbox/Research_at_ETH/Code/DirectLikelihood/cvx');
cvx_startup
cvx_setup

% get appropriate directory
temp = pwd;
root = temp(1:end-4);

% addpath to reservoir data and info
addpath(strcat(root,'/Data/Reservoirs'))
addpath(strcat(root,'/Data/Covariates'))

% addpath to solvers
addpath(strcat(root,'/Solvers'))
addpath(strcat(root,'/Solvers/logdetppa-0'))
addpath(strcat(root,'/Solvers/logdetppa-0/solver'))
addpath(strcat(root,'/Solvers/logdetppa-0/util'))
addpath(strcat(root,'/Solvers/logdetppa-0/solver/mexfun'))
addpath('/Users/armeentaeb/Dropbox/Research_at_ETH/Code/DirectLikelihood');
addpath('/Users/armeentaeb/Dropbox/Research_at_ETH/Code/DirectLikelihood/');
addpath('/Users/armeentaeb/Dropbox/Research_at_ETH/Code/DirectLikelihood/experiment_R_files');


% read reservoir data
[DataY] = xlsread('ReservoirsData');
DataY = DataY(:,2:end);
selRes = [1:9,11:13,15:16,18:29,31:49,51:60]; % These are reservoirs without huge chunk of missing information
DataY = DataY(:,selRes);

[resInfoM,resInfoT] = xlsread('reservoir_summary');

% numeric fields
resInfo.lat = resInfoM(selRes,1);
resInfo.lon = resInfoM(selRes,2);
resInfo.elev = resInfoM(selRes,3);
resInfo.cap = resInfoM(selRes,4);
resInfo.drain = resInfoM(selRes,5);
resInfo.zoneind = resInfoM(selRes,7);
resInfo.basinind = resInfoM(selRes,9);
resInfo.streamind = resInfoM(selRes,11);


% text fields
resInfo.name = resInfoT(selRes+1,1);
resInfo.dam = resInfoT(selRes+1,2);
resInfo.lake = resInfoT(selRes+1,3);
resInfo.hydro = resInfoT(selRes+1,4);
resInfo.basinname = resInfoT(selRes+1,5);
resInfo.zonename = resInfoT(selRes+1,6);
resInfo.basinname = resInfoT(selRes+1,7);
resInfo.streamname = resInfoT(selRes+1,8);


p = 10;
numYears = floor(size(DataY,1)/365);
numMonths = numYears*12 + floor((size(DataY,1)/365-numYears)*12);
% Obtain monthly average reservoir volumes
DataYM = AverageMonthly(DataY,numMonths);
[val,ind] = sort(resInfo.cap,'descend');
DataYM = DataYM(:,ind(1:p));

timePeriod = 1:size(DataYM,1); % start in January 2004 since snowpack data starts

%% Loading Covariates
[DataXM, covariatesName] = loadCovariatesData(size(DataYM,1),strcat(root,'/Data/Covariates'));



%% Create training and validation data
%validation observations from January 2003 - December 2003, January
%2013 - November 2015
% Training and Validation Data
TestInd = [];
TrainInd = setdiff(1:size(DataYM,1),TestInd);
TestY = DataYM(TestInd,:); % reservoirs validation data
TrainY =  DataYM(TrainInd,:); % reservoirs training data
TrainX = DataXM(TrainInd,:); % covariates training data
TestX = DataXM(TestInd,:); % covariates validation data


[TrainYa, TestYa, avgMonthY,varY] = preprocessingData(TrainY,TestY,TrainInd,TestInd);
data = TrainYa;
tot_env = 4;
%env_ind{1}=[1:48,85:10*12]; %normal
env_ind{1}=[1:48,85:8*12];
env_ind{2} = [48+1:12*5,10*12+1:12*11]; %abnormally dry: 2007, 2013
env_ind{3} = [12*5+1:7*12]; %moderought drought: 2008-2009
env_ind{4} = [12*11+1:12*13];

Test_Data = data(8*12+1:10*12,:);

A = load('water_GES');
equivalent_DAGs  = cell(length(A)/p,1);
for i = 1:length(A)/p
    equivalent_DAGs{i} =  A((i-1)*p+1:(i)*p,:);
end



Sigma_train = cell(tot_env,1);
for i = 1:tot_env
    Sigma_train{i} =  cov(data(env_ind{i},:));
    nvec_train(i) = length(env_ind{i});
end

Sigma = Sigma_train;
nvec = nvec_train;
R = ones(p,length(nvec_train));


learn_rate = 0.00001;
perturbed_latent = 0;
latent = 0;
psi_max = 0.5;
rank_est = 2;

global ratio_BIC; ratio_BIC = 1;

[optimal_Bv1,Gamma,d0,score_orig] = score_all_dags_set(equivalent_DAGs);

for DAG_ind = 1:5
    optimal_B_est = optimal_Bv1{DAG_ind};
    optimal_B_est_orig = optimal_B_est;
    
    
    scoren = score_orig(DAG_ind);
    l = 1;
    equivalent_DAGs_est = equivalent_DAGs{DAG_ind};
    equivalent_DAGs_new = equivalent_DAGs_est;
    while l<= length(find(abs(optimal_B_est_orig)>10^(-3)))
        score(DAG_ind,l) = scoren;
        equivalent_DAGs_est = equivalent_DAGs_new;
        current_DAG{DAG_ind,l} = equivalent_DAGs_est;
        ind = (find(abs(optimal_B_est)>10^(-3)));
        [val ind2] = sort(abs(optimal_B_est(ind)),'ascend');
        equivalent_DAGs_new(ind(ind2(1))) = 0;
        equivalent_DAGs2 = cell(1);
        equivalent_DAGs2{1} = equivalent_DAGs_new;
        [optimal_B_est,~,~,scoren] = score_all_dags_set(equivalent_DAGs2);
        optimal_B_est = optimal_B_est{1};
        l = l+1;
    end
end

[val ind] = min(score');
[val ind2] = min(val);
score(ind2,ind(ind2));
equivalent_DAGs_est = current_DAG{ind2,ind(ind2)};
equivalent_DAGs2{1} = equivalent_DAGs_est;
[optimal_B_est,Gamma,d0,scoren] = score_all_dags_set(equivalent_DAGs2);

DAG_1 = equivalent_DAGs_est;

% test performance
test_sigma = cov(Test_Data);
precision= (eye(p)-optimal_B_est{1})'*(diag(d0{1})+Gamma{1}*Gamma{1}')*(eye(p)-optimal_B_est{1});
test_performance_1= -log(det(precision))+trace(precision*test_sigma);


%%%%%%%%%%%%%%%%%%%%%%%%%%
ratio_BIC = 3/4;

[optimal_Bv1,Gamma,d0,score_orig] = score_all_dags_set(equivalent_DAGs);

for DAG_ind = 1:5
    optimal_B_est = optimal_Bv1{DAG_ind};
    optimal_B_est_orig = optimal_B_est;
    
    
    scoren = score_orig(DAG_ind);
    l = 1;
    equivalent_DAGs_est = equivalent_DAGs{DAG_ind};
    equivalent_DAGs_new = equivalent_DAGs_est;
    while l<= length(find(abs(optimal_B_est_orig)>10^(-3)))
        score(DAG_ind,l) = scoren;
        equivalent_DAGs_est = equivalent_DAGs_new;
        current_DAG{DAG_ind,l} = equivalent_DAGs_est;
        ind = (find(abs(optimal_B_est)>10^(-3)));
        [val ind2] = sort(abs(optimal_B_est(ind)),'ascend');
        equivalent_DAGs_new(ind(ind2(1))) = 0;
        equivalent_DAGs2 = cell(1);
        equivalent_DAGs2{1} = equivalent_DAGs_new;
        [optimal_B_est,~,~,scoren] = score_all_dags_set(equivalent_DAGs2);
        optimal_B_est = optimal_B_est{1};
        l = l+1;
    end
end

[val ind] = min(score');
[val ind2] = min(val);
score(ind2,ind(ind2));
equivalent_DAGs_est = current_DAG{ind2,ind(ind2)};
equivalent_DAGs2{1} = equivalent_DAGs_est;
[optimal_B_est,Gamma,d0,scoren] = score_all_dags_set(equivalent_DAGs2);

DAG_2 = equivalent_DAGs_est;

% test performance
test_sigma = cov(Test_Data);
precision= (eye(p)-optimal_B_est{1})'*(diag(d0{1})+Gamma{1}*Gamma{1}')*(eye(p)-optimal_B_est{1});
test_performance_2 = -log(det(precision))+trace(precision*test_sigma);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
ratio_BIC = 1/2;

[optimal_Bv1,Gamma,d0,score_orig] = score_all_dags_set(equivalent_DAGs);

for DAG_ind = 1:5
    optimal_B_est = optimal_Bv1{DAG_ind};
    optimal_B_est_orig = optimal_B_est;
    
    
    scoren = score_orig(DAG_ind);
    l = 1;
    equivalent_DAGs_est = equivalent_DAGs{DAG_ind};
    equivalent_DAGs_new = equivalent_DAGs_est;
    while l<= length(find(abs(optimal_B_est_orig)>10^(-3)))
        score(DAG_ind,l) = scoren;
        equivalent_DAGs_est = equivalent_DAGs_new;
        current_DAG{DAG_ind,l} = equivalent_DAGs_est;
        ind = (find(abs(optimal_B_est)>10^(-3)));
        [val ind2] = sort(abs(optimal_B_est(ind)),'ascend');
        equivalent_DAGs_new(ind(ind2(1))) = 0;
        equivalent_DAGs2 = cell(1);
        equivalent_DAGs2{1} = equivalent_DAGs_new;
        [optimal_B_est,~,~,scoren] = score_all_dags_set(equivalent_DAGs2);
        optimal_B_est = optimal_B_est{1};
        l = l+1;
    end
end

[val ind] = min(score');
[val ind2] = min(val);
score(ind2,ind(ind2));
equivalent_DAGs_est = current_DAG{ind2,ind(ind2)};
equivalent_DAGs2{1} = equivalent_DAGs_est;
[optimal_B_est,Gamma,d0,scoren] = score_all_dags_set(equivalent_DAGs2);

DAG_3 = equivalent_DAGs_est;

% test performance
test_sigma = cov(Test_Data);
precision= (eye(p)-optimal_B_est{1})'*(diag(d0{1})+Gamma{1}*Gamma{1}')*(eye(p)-optimal_B_est{1});
test_performance_3 = -log(det(precision))+trace(precision*test_sigma);


%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
ratio_BIC = 1/4;

[optimal_Bv1,Gamma,d0,score_orig] = score_all_dags_set(equivalent_DAGs);

for DAG_ind = 1:5
    optimal_B_est = optimal_Bv1{DAG_ind};
    optimal_B_est_orig = optimal_B_est;
    
    
    scoren = score_orig(DAG_ind);
    l = 1;
    equivalent_DAGs_est = equivalent_DAGs{DAG_ind};
    equivalent_DAGs_new = equivalent_DAGs_est;
    while l<= length(find(abs(optimal_B_est_orig)>10^(-3)))
        score(DAG_ind,l) = scoren;
        equivalent_DAGs_est = equivalent_DAGs_new;
        current_DAG{DAG_ind,l} = equivalent_DAGs_est;
        ind = (find(abs(optimal_B_est)>10^(-3)));
        [val ind2] = sort(abs(optimal_B_est(ind)),'ascend');
        equivalent_DAGs_new(ind(ind2(1))) = 0;
        equivalent_DAGs2 = cell(1);
        equivalent_DAGs2{1} = equivalent_DAGs_new;
        [optimal_B_est,~,~,scoren] = score_all_dags_set(equivalent_DAGs2);
        optimal_B_est = optimal_B_est{1};
        l = l+1;
    end
end

[val ind] = min(score');
[val ind2] = min(val);
score(ind2,ind(ind2));
equivalent_DAGs_est = current_DAG{ind2,ind(ind2)};
equivalent_DAGs2{1} = equivalent_DAGs_est;
[optimal_B_est,Gamma,d0,scoren] = score_all_dags_set(equivalent_DAGs2);

DAG_4 = equivalent_DAGs_est;

% test performance
test_sigma = cov(Test_Data);
precision= (eye(p)-optimal_B_est{1})'*(diag(d0{1})+Gamma{1}*Gamma{1}')*(eye(p)-optimal_B_est{1});
test_performance_4 = -log(det(precision))+trace(precision*test_sigma);

